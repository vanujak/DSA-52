﻿
using System;

namespace StockMarketTracker
{
    // Entry point of the application
    class Program
    {
        static void Main(string[] args)
        {
            StockMarketApp app = new StockMarketApp();
            app.Run();
        }
    }
}