using System;

namespace StockMarketTracker
{
    // Contains sorting algorithms
    public static class SortingAlgorithms
    {
        // Merge Sort implementation
        public static decimal[] MergeSort(decimal[] array)
        {
            if (array.Length <= 1)
                return array;
        
            int mid = array.Length / 2;
            decimal[] left = new decimal[mid];
            decimal[] right = new decimal[array.Length - mid];
        
            for (int i = 0; i < mid; i++)
                left[i] = array[i];
        
            for (int i = mid; i < array.Length; i++)
                right[i - mid] = array[i];
        
            left = MergeSort(left);
            right = MergeSort(right);
        
            return Merge(left, right);
        }
        
        // Merge helper for MergeSort
        private static decimal[] Merge(decimal[] left, decimal[] right)
        {
            decimal[] result = new decimal[left.Length + right.Length];
            int leftIndex = 0, rightIndex = 0, resultIndex = 0;
        
            while (leftIndex < left.Length && rightIndex < right.Length)
            {
                if (left[leftIndex] <= right[rightIndex])
                {
                    result[resultIndex] = left[leftIndex];
                    leftIndex++;
                }
                else
                {
                    result[resultIndex] = right[rightIndex];
                    rightIndex++;
                }
                resultIndex++;
            }
        
            while (leftIndex < left.Length)
            {
                result[resultIndex] = left[leftIndex];
                leftIndex++;
                resultIndex++;
            }
        
            while (rightIndex < right.Length)
            {
                result[resultIndex] = right[rightIndex];
                rightIndex++;
                resultIndex++;
            }
        
            return result;
        }

        // Quick Sort implementation for Stock objects
        public static void QuickSort(Stock[] array, int low, int high, Func<Stock, decimal> propertySelector)
        {
            if (low < high)
            {
                int pivotIndex = Partition(array, low, high, propertySelector);
                QuickSort(array, low, pivotIndex - 1, propertySelector);
                QuickSort(array, pivotIndex + 1, high, propertySelector);
            }
        }
        
        // Partition helper for QuickSort
        private static int Partition(Stock[] array, int low, int high, Func<Stock, decimal> propertySelector)
        {
            decimal pivot = propertySelector(array[high]);
            int i = low - 1;
        
            for (int j = low; j < high; j++)
            {
                if (propertySelector(array[j]) <= pivot)
                {
                    i++;
                    Stock temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        
            Stock temp1 = array[i + 1];
            array[i + 1] = array[high];
            array[high] = temp1;
        
            return i + 1;
        }
    }
}