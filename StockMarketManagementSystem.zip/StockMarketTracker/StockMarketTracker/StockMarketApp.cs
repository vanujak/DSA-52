using System;
using System.Collections.Generic;

namespace StockMarketTracker
{
    // The main application class
    class StockMarketApp
    {
        private List<Stock> stocks;

        public StockMarketApp()
        {
            // Initialize with some sample stocks
            List<decimal> applePrices = new List<decimal>
            {
                190.50m, 191.20m, 192.53m, 190.22m, 189.30m, 188.52m, 187.45m,
                186.78m, 185.90m, 184.75m, 183.60m, 190.45m, 193.30m, 195.15m,
                200.00m, 204.85m, 210.70m, 208.55m, 212.40m, 215.25m, 220.10m,
                225.95m, 230.80m, 233.65m, 237.50m, 238.35m, 250.20m, 261.05m,
                286.90m, 305.75m
            };

            List<decimal> microsoftPrices = new List<decimal>
            {
                403.78m, 405.65m, 406.22m, 404.10m, 401.55m, 399.30m, 400.20m,
                398.50m, 397.80m, 396.90m, 395.75m, 394.60m, 393.45m, 392.30m,
                391.15m, 390.00m, 388.85m, 387.70m, 386.55m, 385.40m, 384.25m,
                383.10m, 381.95m, 380.80m, 379.65m, 378.50m, 377.35m, 376.20m,
                375.05m, 373.90m
            };

            List<decimal> amazonPrices = new List<decimal>
            {
                178.23m, 177.56m, 179.34m, 180.45m, 178.90m, 175.45m, 176.89m,
                174.50m, 173.80m, 172.75m, 171.60m, 170.45m, 169.30m, 168.15m,
                167.00m, 165.85m, 164.70m, 163.55m, 162.40m, 161.25m, 160.10m,
                158.95m, 157.80m, 156.65m, 155.50m, 154.35m, 153.20m, 152.05m,
                150.90m, 149.75m
            };

            List<decimal> googlePrices = new List<decimal>
            {
                142.65m, 143.10m, 144.78m, 141.98m, 142.34m, 140.23m, 141.56m,
                139.80m, 138.90m, 137.75m, 136.60m, 135.45m, 134.30m, 133.15m,
                132.00m, 130.85m, 129.70m, 128.55m, 127.40m, 126.25m, 125.10m,
                123.95m, 122.80m, 121.65m, 120.50m, 119.35m, 118.20m, 117.05m,
                115.90m, 114.75m
            };

            List<decimal> metaPrices = new List<decimal>
            {
                474.12m, 475.89m, 473.67m, 472.10m, 474.98m, 470.23m, 472.45m,
                469.50m, 468.80m, 467.75m, 466.60m, 465.45m, 464.30m, 463.15m,
                462.00m, 460.85m, 459.70m, 458.55m, 457.40m, 456.25m, 455.10m,
                453.95m, 452.80m, 451.65m, 450.50m, 449.35m, 448.20m, 447.05m,
                445.90m, 444.75m
            };
            stocks = new List<Stock>
            {
                new Stock("AAPL", "Apple Inc.",applePrices),
                new Stock("MSFT", "Microsoft Corporation",microsoftPrices),
                new Stock("AMZN", "Amazon.com Inc.",amazonPrices),
                new Stock("GOOGL", "Alphabet Inc.",googlePrices),
                new Stock("META", "Meta Platforms Inc.",metaPrices)
            };
        }

        public void Run()
        {
            
            
            bool running = true;
            
            // Welcome message with styling
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("===============================================");
            Console.WriteLine("       STOCK MARKET ANALYSIS SYSTEM");
            Console.WriteLine("===============================================");
            Console.ResetColor();
            PrintStyledMessage("A Data Structures & Algorithms Demonstration", ConsoleColor.Yellow);
            Console.WriteLine();

            while (running)
            {
                Console.Clear();
                // Welcome message with styling
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("===============================================");
                Console.WriteLine("       STOCK MARKET MANAGEMENT SYSTEM");
                Console.WriteLine("===============================================");
                Console.ResetColor();
                Console.WriteLine();
                
                
                Console.WriteLine();
                Console.WriteLine("1. List All Stocks");
                Console.WriteLine("2. View Stock Price History");
                Console.WriteLine("3. Find Highest/Lowest Price");
                Console.WriteLine("4. Calculate Moving Average");
                Console.WriteLine("5. Search for a Stock Price");
                Console.WriteLine("6. Sort Stocks by Price");
                Console.WriteLine("7. Predict Basic Trend");
                Console.WriteLine("8. Add New Stock");
                Console.WriteLine("9. Add New Price to Stock");
                Console.WriteLine("0. Exit");
                Console.Write("\nEnter your choice: ");

                string choice = Console.ReadLine();
                Console.Clear();
                
                
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("===============================================");
                Console.WriteLine("       STOCK MARKET MANAGEMENT SYSTEM");
                Console.WriteLine("===============================================");
                Console.ResetColor();
                Console.WriteLine();

                switch (choice)
                {
                    case "1":
                        ListAllStocks();
                        break;
                    case "2":
                        ViewStockPriceHistory();
                        break;
                    case "3":
                        FindHighestLowestPrice();
                        break;
                    case "4":
                        CalculateMovingAverage();
                        break;
                    case "5":
                        SearchForStockPrice();
                        break;
                    case "6":
                        SortStocksByPrice();
                        break;
                    case "7":
                        PredictBasicTrend();
                        break;
                    case "8":
                        AddNewStock();
                        break;
                    case "9":
                        AddNewPrice();
                        break;
                    case "0":
                        running = false;
                        PrintStyledMessage("Thank you for using Stock Market Analysis System. Goodbye!", ConsoleColor.Cyan);
                        break;
                    default:
                        PrintStyledMessage("Invalid option. Please try again.", ConsoleColor.Red);
                        Console.ReadKey();
                        break;
                }
            }
        }

        // List all stocks
        private void ListAllStocks()
        {
            Console.WriteLine("\n--- All Stocks ---");
            Console.WriteLine("{0,-10} {1,-25} {2,-15}", "Symbol", "Company Name", "Current Price");
            Console.WriteLine(new string('-', 65));
            
            foreach (var stock in stocks)
            {
                Console.WriteLine("{0,-10} {1,-25} {2,-15:C2}",
                    stock.Symbol,
                    stock.Name,
                    stock.PriceHistory.GetLast());
            }

            WaitForKeyPress();
        }
        private void PrintStyledMessage(string message, ConsoleColor color = ConsoleColor.White)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        // View price history for a specific stock
        private void ViewStockPriceHistory()
        {
            Console.Clear();
            Console.WriteLine("=== STOCK PRICE HISTORY ===");

            DisplayStocksForSelection();

            Console.Write("\nSelect a stock (1-" + stocks.Count + "): ");
            if (int.TryParse(Console.ReadLine(), out int selection) && selection >= 1 && selection <= stocks.Count)
            {
                Stock selectedStock = stocks[selection - 1];
                Console.Clear();
                Console.WriteLine($"Price History for {selectedStock.Symbol} - {selectedStock.Name}");
                Console.WriteLine("------------------------------------------");

                int days = selectedStock.PriceHistory.Count;
                for (int i = 0; i < days; i++)
                {
                    Console.WriteLine($"Day {i + 1}: ${selectedStock.PriceHistory.GetAt(i)}");
                }

                Console.WriteLine("\nStatistics:");
                Console.WriteLine($"Average Price: ${Math.Round(selectedStock.PriceHistory.Average(), 2)}");
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }

            WaitForKeyPress();
        }
        
        // Find highest/lowest price manually
        private void FindHighestLowestPrice()
        {
            Console.Clear();
            Console.WriteLine("=== HIGHEST/LOWEST PRICE ===");

            DisplayStocksForSelection();

            Console.Write("\nSelect a stock (1-" + stocks.Count + "): ");
            if (int.TryParse(Console.ReadLine(), out int selection) && selection >= 1 && selection <= stocks.Count)
            {
                Stock selectedStock = stocks[selection - 1];
                Console.WriteLine($"\nAnalyzing {selectedStock.Symbol} - {selectedStock.Name}");

                // Find highest and lowest prices manually
                decimal highestPrice = selectedStock.PriceHistory.Max();
                decimal lowestPrice = selectedStock.PriceHistory.Min();

                Console.WriteLine($"Highest Price: ${highestPrice}");
                Console.WriteLine($"Lowest Price: ${lowestPrice}");
                Console.WriteLine($"Price Range: ${highestPrice - lowestPrice}");

                // Find the day with highest and lowest price
                int highestDay = selectedStock.PriceHistory.IndexOf(highestPrice) + 1;
                int lowestDay = selectedStock.PriceHistory.IndexOf(lowestPrice) + 1;

                Console.WriteLine($"Highest Price occurred on Day {highestDay}");
                Console.WriteLine($"Lowest Price occurred on Day {lowestDay}");
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }

            WaitForKeyPress();
        }

        // Calculate moving average using our custom Queue / Sliding Window
        private void CalculateMovingAverage()
        {
            Console.Clear();
            Console.WriteLine("=== MOVING AVERAGE CALCULATION ===");

            DisplayStocksForSelection();

            Console.Write("\nSelect a stock (1-" + stocks.Count + "): ");
            if (int.TryParse(Console.ReadLine(), out int selection) && selection >= 1 && selection <= stocks.Count)
            {
                Stock selectedStock = stocks[selection - 1];

                Console.Write("\nEnter window size for moving average (e.g., 5 days): ");
                if (int.TryParse(Console.ReadLine(), out int windowSize) && windowSize > 0)
                {
                    if (windowSize > selectedStock.PriceHistory.Count)
                    {
                        Console.WriteLine($"Window size is too large. Maximum allowed is {selectedStock.PriceHistory.Count}.");
                        WaitForKeyPress();
                        return;
                    }

                    Console.Clear();
                    Console.WriteLine($"{windowSize}-Day Moving Average for {selectedStock.Symbol}");
                    Console.WriteLine("------------------------------------------");

                    // Implement sliding window with our custom queue
                    CustomQueue window = new CustomQueue(windowSize);

                    // Calculate and display moving averages
                    for (int i = 0; i < selectedStock.PriceHistory.Count; i++)
                    {
                        decimal currentPrice = selectedStock.PriceHistory.GetAt(i);

                        // Add the current price to the window
                        window.Enqueue(currentPrice);

                        // Display moving average once we have enough data points
                        if (i >= windowSize - 1)
                        {
                            decimal average = Math.Round(window.Sum() / window.Count(), 2);
                            Console.WriteLine($"Day {i + 1}: ${currentPrice} | {windowSize}-Day MA: ${average}");
                        }
                        else
                        {
                            Console.WriteLine($"Day {i + 1}: ${currentPrice} | Accumulating data...");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Invalid window size.");
                }
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }

            WaitForKeyPress();
        }

        // Search for a stock price using Binary Search
        private void SearchForStockPrice()
        {
            Console.Clear();
            Console.WriteLine("=== SEARCH FOR A STOCK PRICE ===");

            DisplayStocksForSelection();

            Console.Write("\nSelect a stock (1-" + stocks.Count + "): ");
            if (int.TryParse(Console.ReadLine(), out int selection) && selection >= 1 && selection <= stocks.Count)
            {
                Stock selectedStock = stocks[selection - 1];

                Console.Write("\nEnter a price to search for: $");
                if (decimal.TryParse(Console.ReadLine(), out decimal targetPrice))
                {
                    Console.WriteLine($"\nSearching for ${targetPrice} in {selectedStock.Symbol}'s price history...");

                    // Create a sorted copy of the price history for binary search
                    decimal[] prices = selectedStock.PriceHistory.ToArray();
                    prices = SortingAlgorithms.MergeSort(prices);

                    // Perform binary search
                    int result = SearchingAlgorithms.BinarySearch(prices, targetPrice);

                    if (result != -1)
                    {
                        Console.WriteLine($"Price ${prices[result]} found in the sorted price list at position {result + 1}.");

                        // Find all occurrences in the original price history
                        List<int> days = new List<int>();
                        for (int i = 0; i < selectedStock.PriceHistory.Count; i++)
                        {
                            if (Math.Round(selectedStock.PriceHistory.GetAt(i), 2) == Math.Round(targetPrice, 2))
                            {
                                days.Add(i + 1);
                            }
                        }

                        if (days.Count > 0)
                        {
                            Console.WriteLine($"This price occurred on day(s): {string.Join(", ", days)}");
                        }

                        // Find closest price if not exact match
                        if (Math.Round(prices[result], 2) != Math.Round(targetPrice, 2))
                        {
                            Console.WriteLine($"Note: The exact price ${targetPrice} was not found. The closest price is ${prices[result]}.");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"The price ${targetPrice} was not found.");

                        // Find the closest price
                        decimal closest = SearchingAlgorithms.FindClosestPrice(prices, targetPrice);
                        Console.WriteLine($"The closest price is ${closest}");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid price.");
                }
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }

            WaitForKeyPress();
        }

        // Sort stocks by price using our Merge Sort implementation
        private void SortStocksByPrice()
        {
            Console.Clear();
            Console.WriteLine("=== SORT STOCKS BY PRICE ===");
            Console.WriteLine("1. Sort by Current Price");
            Console.WriteLine("2. Sort by Average Price");
            Console.WriteLine("3. Sort by Highest Price");
            Console.WriteLine("4. Sort by Lowest Price");
            Console.Write("\nChoose sorting criteria: ");

            string criteria = Console.ReadLine();

            // Create a copy of the stocks list
            Stock[] stocksArray = new Stock[stocks.Count];
            stocks.CopyTo(stocksArray);

            // Sort based on criteria
            switch (criteria)
            {
                case "1":
                    Console.WriteLine("\nSorting stocks by current price...");
                    SortingAlgorithms.QuickSort(stocksArray, 0, stocksArray.Length - 1, stock => stock.PriceHistory.GetLast());
                    break;
                case "2":
                    Console.WriteLine("\nSorting stocks by average price...");
                    SortingAlgorithms.QuickSort(stocksArray, 0, stocksArray.Length - 1, stock => stock.PriceHistory.Average());
                    break;
                case "3":
                    Console.WriteLine("\nSorting stocks by highest price...");
                    SortingAlgorithms.QuickSort(stocksArray, 0, stocksArray.Length - 1, stock => stock.PriceHistory.Max());
                    break;
                case "4":
                    Console.WriteLine("\nSorting stocks by lowest price...");
                    SortingAlgorithms.QuickSort(stocksArray, 0, stocksArray.Length - 1, stock => stock.PriceHistory.Min());
                    break;
                default:
                    Console.WriteLine("Invalid criteria. Using current price.");
                    SortingAlgorithms.QuickSort(stocksArray, 0, stocksArray.Length - 1, stock => stock.PriceHistory.GetLast());
                    break;
            }

            Console.WriteLine("\nSorted Stocks:");
            Console.WriteLine("------------------------------------------");

            for (int i = 0; i < stocksArray.Length; i++)
            {
                Stock stock = stocksArray[i];
                decimal value = 0;

                switch (criteria)
                {
                    case "1":
                        value = stock.PriceHistory.GetLast();
                        Console.WriteLine($"{i + 1}. {stock.Symbol} - {stock.Name}: Current Price: ${value}");
                        break;
                    case "2":
                        value = Math.Round(stock.PriceHistory.Average(), 2);
                        Console.WriteLine($"{i + 1}. {stock.Symbol} - {stock.Name}: Average Price: ${value}");
                        break;
                    case "3":
                        value = stock.PriceHistory.Max();
                        Console.WriteLine($"{i + 1}. {stock.Symbol} - {stock.Name}: Highest Price: ${value}");
                        break;
                    case "4":
                        value = stock.PriceHistory.Min();
                        Console.WriteLine($"{i + 1}. {stock.Symbol} - {stock.Name}: Lowest Price: ${value}");
                        break;
                    default:
                        value = stock.PriceHistory.GetLast();
                        Console.WriteLine($"{i + 1}. {stock.Symbol} - {stock.Name}: Current Price: ${value}");
                        break;
                }
            }

            WaitForKeyPress();
        }

        // Predict basic trend using a simple decision tree
        private void PredictBasicTrend()
        {
            Console.Clear();
            Console.WriteLine("=== PREDICT BASIC TREND ===");

            DisplayStocksForSelection();

            Console.Write("\nSelect a stock (1-" + stocks.Count + "): ");
            if (int.TryParse(Console.ReadLine(), out int selection) && selection >= 1 && selection <= stocks.Count)
            {
                Stock selectedStock = stocks[selection - 1];
                TrendAnalyzer.PredictTrend(selectedStock);
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }

            WaitForKeyPress();
        }

        // Add a new stock to the list
        private void AddNewStock()
        {
            Console.Clear();
            Console.WriteLine("=== ADD NEW STOCK ===");

            Console.Write("Enter stock symbol (e.g., AAPL): ");
            string symbol = Console.ReadLine().ToUpper();

            // Check if stock already exists
            bool stockExists = false;
            foreach (var stock in stocks)
            {
                if (stock.Symbol == symbol)
                {
                    stockExists = true;
                    break;
                }
            }

            if (stockExists)
            {
                Console.WriteLine($"Stock with symbol {symbol} already exists!");
                WaitForKeyPress();
                return;
            }

            Console.Write("Enter stock name (e.g., Apple Inc.): ");
            string name = Console.ReadLine();

            // Create new stock and add it to the list
            Stock newStock = new Stock(symbol, name,null);
            stocks.Add(newStock);

            Console.WriteLine($"\nStock {symbol} - {name} added successfully!");
            Console.WriteLine("Would you like to add some initial price data? (Y/N)");

            if (Console.ReadLine().ToUpper() == "Y")
            {
                Console.Write("How many days of price data to add? ");
                if (int.TryParse(Console.ReadLine(), out int days) && days > 0)
                {
                    for (int i = 0; i < days; i++)
                    {
                        Console.Write($"Enter price for day {i + 1}: $");
                        if (decimal.TryParse(Console.ReadLine(), out decimal price) && price >= 0)
                        {
                            newStock.PriceHistory.Add(price);
                        }
                        else
                        {
                            Console.WriteLine("Invalid price. Using $100 as default.");
                            newStock.PriceHistory.Add(100);
                        }
                    }
                    Console.WriteLine("Price data added successfully!");
                }
                else
                {
                    Console.WriteLine("Invalid number of days.");
                }
            }
            else
            {
                // Add some default prices
                Console.WriteLine("Adding some default price data...");
                Random random = new Random();
                for (int i = 0; i < 5; i++)
                {
                    decimal price = Math.Round((decimal)(random.NextDouble() * 450 + 50), 2);
                    newStock.PriceHistory.Add(price);
                }
                Console.WriteLine("Default price data added.");
            }

            WaitForKeyPress();
        }

        // Add a new price to an existing stock
        private void AddNewPrice()
        {
            Console.Clear();
            Console.WriteLine("=== ADD NEW PRICE TO STOCK ===");

            DisplayStocksForSelection();

            Console.Write("\nSelect a stock (1-" + stocks.Count + "): ");
            if (int.TryParse(Console.ReadLine(), out int selection) && selection >= 1 && selection <= stocks.Count)
            {
                Stock selectedStock = stocks[selection - 1];
                Console.WriteLine($"\nAdding new price for {selectedStock.Symbol} - {selectedStock.Name}");

                Console.Write("Enter new price: $");
                if (decimal.TryParse(Console.ReadLine(), out decimal price) && price >= 0)
                {
                    selectedStock.PriceHistory.Add(price);
                    Console.WriteLine($"New price ${price} added successfully!");

                    // Show updated price statistics
                    Console.WriteLine("\nUpdated Statistics:");
                    Console.WriteLine($"Current Price: ${selectedStock.PriceHistory.GetLast()}");
                    Console.WriteLine($"Average Price: ${Math.Round(selectedStock.PriceHistory.Average(), 2)}");

                    // Calculate daily change if we have at least 2 prices
                    if (selectedStock.PriceHistory.Count >= 2)
                    {
                        decimal previousPrice = selectedStock.PriceHistory.GetAt(selectedStock.PriceHistory.Count - 2);
                        decimal change = price - previousPrice;
                        decimal percentChange = Math.Round((change / previousPrice) * 100, 2);

                        Console.WriteLine($"Change from previous price: ${Math.Round(change, 2)} ({percentChange}%)");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid price.");
                }
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }

            WaitForKeyPress();
        }

        // Helper method to wait for keypress
        private void WaitForKeyPress()
        {
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }

        // Helper method to display stocks for selection
        private void DisplayStocksForSelection()
        {
            for (int i = 0; i < stocks.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {stocks[i].Symbol} - {stocks[i].Name}");
            }
        }
    }
}