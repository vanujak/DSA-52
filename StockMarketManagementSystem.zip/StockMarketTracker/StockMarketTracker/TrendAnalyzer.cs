using System;

namespace StockMarketTracker
{
    // Contains trend prediction logic
    public static class TrendAnalyzer
    {
        // Predict basic trend using a simple decision tree
        public static void PredictTrend(Stock stock)
        {
            decimal[] prices = stock.PriceHistory.ToArray();
            decimal[] priceChanges = new decimal[prices.Length - 1];

            for (int i = 1; i < prices.Length; i++)
            {
                priceChanges[i - 1] = prices[i] - prices[i - 1];
            }

            int positiveChanges = 0;
            int negativeChanges = 0;
            int noChanges = 0;
            decimal sumChanges = 0;

            foreach (decimal change in priceChanges)
            {
                if (change > 0) positiveChanges++;
                else if (change < 0) negativeChanges++;
                else noChanges++;

                sumChanges += change;
            }

            decimal averageChange = sumChanges / priceChanges.Length;

            // Calculate recent average (last 5 days or less)
            decimal recentSum = 0;
            int recentCount = Math.Min(5, priceChanges.Length);

            for (int i = priceChanges.Length - recentCount; i < priceChanges.Length; i++)
            {
                recentSum += priceChanges[i];
            }

            decimal recentAverage = recentSum / recentCount;

            // Build a simple trend prediction "tree"
            Console.WriteLine("Decision Tree Analysis:");
            Console.WriteLine($"- Total data points: {prices.Length}");
            Console.WriteLine($"- Positive price movements: {positiveChanges}");
            Console.WriteLine($"- Negative price movements: {negativeChanges}");
            Console.WriteLine($"- No change days: {noChanges}");
            Console.WriteLine($"- Average price change: ${Math.Round(averageChange, 2)}");
            Console.WriteLine($"- Recent {recentCount}-day average change: ${Math.Round(recentAverage, 2)}");

            // Visualize recent trend with ASCII art
            Console.WriteLine("\nRecent Price Trend:");
            Console.Write("│");

            int startIndex = Math.Max(0, prices.Length - 10);
            for (int i = startIndex; i < prices.Length; i++)
            {
                Console.Write($" ${prices[i]} │");
            }
            Console.WriteLine();

            // Make prediction based on simple rules
            Console.WriteLine("\nPrediction:");
            if (recentAverage > 0 && positiveChanges > negativeChanges)
            {
                Console.WriteLine("UPWARD TREND ↑ - The stock shows positive momentum.");
            }
            else if (recentAverage < 0 && positiveChanges < negativeChanges)
            {
                Console.WriteLine("DOWNWARD TREND ↓ - The stock shows negative momentum.");
            }
            else if (Math.Abs(recentAverage) < 1)
            {
                Console.WriteLine("SIDEWAYS TREND ↔ - The stock is trading in a range.");
            }
            else
            {
                Console.WriteLine("MIXED SIGNALS - The trend is unclear based on available data.");
            }
            
        }
    }
}