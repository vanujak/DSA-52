

using System;

namespace StockMarketTracker
{
    // Represents a single stock with its properties and price history
    public class Stock
    {
        public string Symbol { get; set; }
        public string Name { get; set; }
        public CustomLinkedList PriceHistory { get; set; }

        public Stock(string symbol, string name,List<decimal> prices)
        {
            Symbol = symbol;
            Name = name;
            PriceHistory = new CustomLinkedList();
            if (prices != null)
            {
                for (int i = 0; i < prices.Count; i++)
                {
                
                    PriceHistory.Add(prices[i]);
                }
            }
            // for (int i = 0; i < prices.Count; i++)
            // {
            //     
            //     PriceHistory.Add(prices[i]);
            // }
            
        }

        public override string ToString()
        {
            return $"{Symbol} - {Name}: Current Price: ${(PriceHistory.Count > 0 ? PriceHistory.GetLast() : 0)}";
        }
    }
}