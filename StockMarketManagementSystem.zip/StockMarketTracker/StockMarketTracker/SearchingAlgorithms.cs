using System;

namespace StockMarketTracker
{
    // Contains searching algorithms
    public static class SearchingAlgorithms
    {
        // Binary Search implementation
        public static int BinarySearch(decimal[] sortedArray, decimal target)
        {
            int left = 0;
            int right = sortedArray.Length - 1;

            while (left <= right)
            {
                int mid = left + (right - left) / 2;

                if (Math.Round(sortedArray[mid], 2) == Math.Round(target, 2))
                    return mid;

                if (sortedArray[mid] < target)
                    left = mid + 1;
                else
                    right = mid - 1;
            }

            return left < sortedArray.Length ? left : -1;
        }

        // Find the closest value in a sorted array
        public static decimal FindClosestPrice(decimal[] sortedArray, decimal target)
        {
            if (sortedArray.Length == 0)
                throw new ArgumentException("Array is empty");

            if (sortedArray.Length == 1)
                return sortedArray[0];

            int left = 0;
            int right = sortedArray.Length - 1;

            while (left <= right)
            {
                int mid = left + (right - left) / 2;

                if (sortedArray[mid] == target)
                    return sortedArray[mid];

                if (sortedArray[mid] < target)
                    left = mid + 1;
                else
                    right = mid - 1;
            }

            if (left == 0)
                return sortedArray[0];

            if (left == sortedArray.Length)
                return sortedArray[sortedArray.Length - 1];

            decimal diff1 = Math.Abs(sortedArray[left - 1] - target);
            decimal diff2 = Math.Abs(sortedArray[left] - target);

            return diff1 <= diff2 ? sortedArray[left - 1] : sortedArray[left];
        }
    }
}