using System;

namespace StockMarketTracker
{
    // Custom implementation of a Queue (for sliding window)
    class CustomQueue
    {
        private decimal[] items;
        private int front;
        private int rear;
        private int capacity;
        private int count;

        public CustomQueue(int size)
        {
            items = new decimal[size];
            capacity = size;
            front = 0;
            rear = -1;
            count = 0;
        }

        // Add an item to the queue
        public void Enqueue(decimal value)
        {
            if (count == capacity)
            {
                // If queue is full, remove the oldest item
                Dequeue();
            }

            rear = (rear + 1) % capacity;
            items[rear] = value;
            count++;
        }

        // Remove and return the oldest item
        public decimal Dequeue()
        {
            if (count == 0)
            {
                throw new InvalidOperationException("Queue is empty");
            }

            decimal value = items[front];
            front = (front + 1) % capacity;
            count--;

            return value;
        }

        // Get number of items in the queue
        public int Count()
        {
            return count;
        }

        // Calculate sum of all items
        public decimal Sum()
        {
            decimal sum = 0;

            if (count == 0)
                return sum;

            int index = front;
            for (int i = 0; i < count; i++)
            {
                sum += items[index];
                index = (index + 1) % capacity;
            }

            return sum;
        }
    }
}