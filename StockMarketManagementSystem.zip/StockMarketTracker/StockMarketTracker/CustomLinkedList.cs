using System;

namespace StockMarketTracker
{
    // Custom implementation of a Linked List for storing price history
    public class CustomLinkedList
    {
        // Node class for the linked list
        private class Node
        {
            public decimal Value { get; set; }
            public Node Next { get; set; }

            public Node(decimal value)
            {
                Value = value;
                Next = null;
            }
        }

        private Node head;
        private Node tail;
        public int Count { get; private set; }

        public CustomLinkedList()
        {
            head = null;
            tail = null;
            Count = 0;
        }

        // Add a new value to the end of the list
        public void Add(decimal value)
        {
            Node newNode = new Node(value);

            if (head == null)
            {
                head = newNode;
                tail = newNode;
            }
            else
            {
                tail.Next = newNode;
                tail = newNode;
            }

            Count++;
        }

        // Get value at a specific index
        public decimal GetAt(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException("Index is out of range");
            }

            Node current = head;
            for (int i = 0; i < index; i++)
            {
                current = current.Next;
            }

            return current.Value;
        }

        // Get the last value in the list
        public decimal GetLast()
        {
            if (tail == null)
            {
                throw new InvalidOperationException("List is empty");
            }

            return tail.Value;
        }

        // Get all values as an array
        public decimal[] ToArray()
        {
            decimal[] array = new decimal[Count];
            Node current = head;

            for (int i = 0; i < Count; i++)
            {
                array[i] = current.Value;
                current = current.Next;
            }

            return array;
        }

        // Calculate average of all values
        public decimal Average()
        {
            if (Count == 0)
                return 0;

            decimal sum = 0;
            Node current = head;

            while (current != null)
            {
                sum += current.Value;
                current = current.Next;
            }

            return sum / Count;
        }

        // Find max value
        public decimal Max()
        {
            if (Count == 0)
                throw new InvalidOperationException("List is empty");

            decimal max = decimal.MinValue;
            Node current = head;

            while (current != null)
            {
                if (current.Value > max)
                    max = current.Value;

                current = current.Next;
            }

            return max;
        }

        // Find min value
        public decimal Min()
        {
            if (Count == 0)
                throw new InvalidOperationException("List is empty");

            decimal min = decimal.MaxValue;
            Node current = head;

            while (current != null)
            {
                if (current.Value < min)
                    min = current.Value;

                current = current.Next;
            }

            return min;
        }

        // Find index of a value
        public int IndexOf(decimal value)
        {
            Node current = head;
            int index = 0;

            while (current != null)
            {
                if (current.Value == value)
                    return index;

                current = current.Next;
                index++;
            }

            return -1;
        }
        
        // Convert linked list to a generic List<decimal>
        public List<decimal> ToList()
        {
            List<decimal> list = new List<decimal>(Count);
            Node current = head;

            while (current != null)
            {
                list.Add(current.Value);
                current = current.Next;
            }

            return list;
        }
    }
}